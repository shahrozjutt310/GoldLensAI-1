# GoldLens AI starter Android app

This is a free-first educational UI starter project for Android. It contains a dark gold-themed interface, five sections, timeframe controls, and clearly labeled demo chart visuals.

## Important limitations
- No live XAUUSD feed is connected.
- Chart candles are illustrative demo data, not current prices.
- AI chat, microphone speech recognition, spoken replies, and live news are not connected.
- The app does not provide trading signals or execute trades.

## Build
Requires Android SDK 35, JDK 17, and Gradle 8.9 or compatible Android Gradle Plugin 8.7.3 setup.
From the project root, configure `local.properties` with your SDK path, then run:
`gradle assembleDebug`
The APK should be generated at `app/build/outputs/apk/debug/app-debug.apk`.

On Android, a compatible Android IDE can open this Gradle project. Building on-device may require extra SDK setup and sufficient free storage/RAM.
