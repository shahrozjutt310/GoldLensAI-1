package com.goldlensai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Newspaper
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF050B13)
private val Panel = Color(0xFF0B1B2C)
private val Gold = Color(0xFFFFD166)
private val Muted = Color(0xFFB8C2D0)
private val Green = Color(0xFF70E3C7)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GoldLensApp() }
    }
}

@Composable
fun GoldLensApp() {
    var tab by remember { mutableStateOf(0) }
    var language by remember { mutableStateOf("Roman Urdu") }
    var voice by remember { mutableStateOf(false) }
    var timeframe by remember { mutableStateOf("M15") }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Gold, background = Bg, surface = Panel,
        onPrimary = Bg, onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                NavigationBar(containerColor = Panel) {
                    val labels = listOf("Home", "Chart", "Assistant", "News", "Settings")
                    val icons = listOf(Icons.Default.Home, Icons.Default.ShowChart, Icons.Default.Chat,
                        Icons.Default.Newspaper, Icons.Default.Settings)
                    labels.forEachIndexed { i, label ->
                        NavigationBarItem(
                            selected = tab == i,
                            onClick = { tab = i },
                            icon = { Icon(icons[i], contentDescription = label) },
                            label = { Text(label, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Gold, selectedTextColor = Gold,
                                unselectedIconColor = Muted, unselectedTextColor = Muted,
                                indicatorColor = Color(0xFF183047)
                            )
                        )
                    }
                }
            }
        ) { padding ->
            Box(Modifier.fillMaxSize().padding(padding).background(Bg)) {
                when (tab) {
                    0 -> HomePage(timeframe, { timeframe = it }, language)
                    1 -> ChartPage(timeframe, { timeframe = it })
                    2 -> AssistantPage(language, { language = it }, voice, { voice = it })
                    3 -> NewsPage()
                    else -> SettingsPage(language, { language = it }, voice, { voice = it },
                        timeframe, { timeframe = it })
                }
            }
        }
    }
}

@Composable
private fun Page(title: String, subtitle: String, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxSize().background(Bg).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(title, color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Text(subtitle, color = Muted, fontSize = 13.sp)
        content()
    }
}

@Composable
private fun PanelCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, color = Gold, fontWeight = FontWeight.Bold)
            content()
        }
    }
}

@Composable
private fun HomePage(tf: String, setTf: (String) -> Unit, language: String) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("GoldLens AI", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Text("Gold market learning assistant", color = Muted)
        }
        item {
            PanelCard("XAUUSD • GOLD") {
                Text("LIVE DATA NOT CONNECTED", color = Color(0xFFFF8A80), fontWeight = FontWeight.Bold)
                Text("This starter app uses demo/sample chart data only. It does not show the current gold price.", color = Muted)
                Text("Last update: No market provider configured", color = Muted, fontSize = 12.sp)
            }
        }
        item {
            PanelCard("Educational snapshot") {
                Text("Trend: Demo example only", color = Color.White)
                Text("RSI / indicators: Not calculated from live data", color = Muted)
                Text("Language: $language", color = Muted)
            }
        }
        item {
            PanelCard("Chart timeframe") { Timeframes(tf, setTf) }
        }
        item {
            Text("Use this app to learn chart terminology. It does not provide trading signals or place trades.", color = Muted, fontSize = 12.sp)
        }
    }
}

@Composable
private fun ChartPage(tf: String, setTf: (String) -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Live Chart", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Text("XAUUSD • $tf", color = Muted)
        PanelCard("DEMO CHART — NOT LIVE") {
            Text("Illustrative candles only; no live provider is connected.", color = Muted)
            DemoCandles(Modifier.fillMaxWidth().height(230.dp))
        }
        PanelCard("Timeframe") { Timeframes(tf, setTf) }
        PanelCard("Learning note") {
            Text("Candles show example open, high, low and close values. They are not current prices.", color = Muted)
        }
    }
}

@Composable
private fun DemoCandles(modifier: Modifier = Modifier) {
    val values = listOf(0.42f,0.55f,0.49f,0.63f,0.57f,0.72f,0.61f,0.47f,0.53f,0.40f,0.46f,0.58f)
    Canvas(modifier.background(Color(0xFF07121F)).padding(8.dp)) {
        val step = size.width / (values.size + 1)
        values.forEachIndexed { i, v ->
            val x = step * (i + 1)
            val mid = size.height * v
            val high = mid - size.height * 0.13f
            val low = mid + size.height * 0.13f
            val up = i % 3 != 0
            val c = if (up) Green else Color(0xFFFF7B72)
            drawLine(c, Offset(x, high), Offset(x, low), strokeWidth = 2.dp.toPx())
            val openY = mid + if (up) 12.dp.toPx() else -12.dp.toPx()
            val closeY = mid + if (up) -12.dp.toPx() else 12.dp.toPx()
            val top = minOf(openY, closeY)
            drawRect(c, topLeft = Offset(x - 5.dp.toPx(), top),
                size = androidx.compose.ui.geometry.Size(10.dp.toPx(), maxOf(5.dp.toPx(), kotlin.math.abs(openY-closeY))))
        }
    }
}

@Composable
private fun AssistantPage(
    language: String, setLanguage: (String) -> Unit,
    voice: Boolean, setVoice: (Boolean) -> Unit
) {
    var question by remember { mutableStateOf("") }
    var answer by remember { mutableStateOf("Demo assistant: live market data and AI service are not connected yet.") }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("AI Assistant", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Text("Urdu / Roman Urdu interface preview", color = Muted)
        OutlinedTextField(
            value = question, onValueChange = { question = it },
            modifier = Modifier.fillMaxWidth(), label = { Text("Ask a learning question") },
            minLines = 2
        )
        Button(onClick = {
            answer = when (language) {
                "اردو" -> "یہ صرف ڈیمو ہے۔ ابھی AI یا لائیو مارکیٹ ڈیٹا منسلک نہیں۔"
                "Roman Urdu" -> "Yeh demo hai. Abhi AI ya live market data connect nahi."
                else -> "This is a demo. AI and live market data are not connected."
            }
        }, modifier = Modifier.fillMaxWidth()) { Text("Show demo response") }
        PanelCard("Response") { Text(answer, color = Muted) }
        Text("Microphone and spoken replies are not implemented in this starter build.", color = Muted, fontSize = 12.sp)
        PanelCard("Language") { LanguageOptions(language, setLanguage) }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Voice output (visual setting only)", color = Muted, modifier = Modifier.weight(1f))
            Switch(checked = voice, onCheckedChange = setVoice)
        }
    }
}

@Composable
private fun NewsPage() {
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Market News", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        PanelCard("News feed not connected") {
            Text("No live headlines are displayed. Connect a legitimate news source before showing real news.", color = Muted)
        }
        PanelCard("Learning topics") {
            listOf("US dollar and gold", "Interest rates", "Inflation reports", "Central-bank announcements").forEach {
                Text("• $it", color = Muted)
            }
        }
    }
}

@Composable
private fun SettingsPage(
    language: String, setLanguage: (String) -> Unit,
    voice: Boolean, setVoice: (Boolean) -> Unit,
    tf: String, setTf: (String) -> Unit
) {
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Settings", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        PanelCard("Language") { LanguageOptions(language, setLanguage) }
        PanelCard("Default timeframe") { Timeframes(tf, setTf) }
        PanelCard("Voice output") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Enabled (setting only)", color = Muted, modifier = Modifier.weight(1f))
                Switch(checked = voice, onCheckedChange = setVoice)
            }
        }
        PanelCard("Connections") {
            Text("Market data: Not connected", color = Color(0xFFFF8A80))
            Text("AI service: Not connected", color = Muted)
            Text("News source: Not connected", color = Muted)
        }
    }
}

@Composable
private fun Timeframes(selected: String, onSelect: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf(listOf("M1", "M5", "M15", "M30"), listOf("H1", "H4", "D1")).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { tf ->
                    FilterChip(selected = selected == tf, onClick = { onSelect(tf) }, label = { Text(tf) })
                }
            }
        }
    }
}

@Composable
private fun LanguageOptions(selected: String, onSelect: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf("English", "اردو", "Roman Urdu").forEach { lang ->
            FilterChip(selected = selected == lang, onClick = { onSelect(lang) }, label = { Text(lang) })
        }
    }
}
